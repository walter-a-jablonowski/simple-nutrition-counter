# Comments for Bulk Price Update

we currently can't update foods with variants

- Karamalz
- Avocado
- Zitronenmelisse 2 vendor
- Wiltmann Salami
- Snickers
- Banane

